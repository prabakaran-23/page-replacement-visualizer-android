package com.example.page_replacement;


import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.*;
import android.view.View;

import java.util.*;

public class MainActivity extends AppCompatActivity {

    EditText inputPages, inputFrames;
    Spinner algorithmSpinner;
    Button runBtn;
    TextView outputText, summaryText;

    String[] algorithms = {"FIFO", "LRU", "Optimal"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        inputPages = findViewById(R.id.inputPages);
        inputFrames = findViewById(R.id.inputFrames);
        algorithmSpinner = findViewById(R.id.algorithmSpinner);
        runBtn = findViewById(R.id.runBtn);
        outputText = findViewById(R.id.outputText);
        summaryText = findViewById(R.id.summaryText);

        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this, android.R.layout.simple_spinner_dropdown_item, algorithms);
        algorithmSpinner.setAdapter(adapter);

        runBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                runSimulation();
            }
        });

        // Example defaults
        inputPages.setText("7,0,1,2,0,3,0,4,2,3,0,3,2");
        inputFrames.setText("3");
    }

    private void runSimulation() {
        String raw = inputPages.getText().toString().trim();
        String framesStr = inputFrames.getText().toString().trim();

        if (raw.isEmpty()) {
            toast("Enter a reference string."); return;
        }
        if (framesStr.isEmpty()) {
            toast("Enter number of frames."); return;
        }

        int frames;
        try { frames = Integer.parseInt(framesStr); }
        catch (NumberFormatException e) { toast("Frames must be a number."); return; }
        if (frames <= 0 || frames > 10) { toast("Frames must be between 1 and 10 for this demo."); return; }

        List<Integer> refs = parseRefs(raw);
        if (refs.isEmpty()) { toast("Could not parse the reference string."); return; }

        String algo = (String) algorithmSpinner.getSelectedItem();

        SimulationResult result;
        switch (algo) {
            case "FIFO":    result = simulateFIFO(refs, frames); break;
            case "LRU":     result = simulateLRU(refs, frames); break;
            case "Optimal": result = simulateOptimal(refs, frames); break;
            default:        result = simulateFIFO(refs, frames);
        }

        summaryText.setText(
                "Algorithm: " + algo +
                        "   Frames: " + frames +
                        "   References: " + refs.size() +
                        "   Faults: " + result.faults +
                        "   Hits: " + result.hits
        );
        outputText.setText(result.tableText);
    }

    private List<Integer> parseRefs(String raw) {
        List<Integer> out = new ArrayList<>();
        String[] parts = raw.split("[,\\s]+");
        for (String p : parts) {
            if (p.trim().isEmpty()) continue;
            try { out.add(Integer.parseInt(p.trim())); }
            catch (NumberFormatException ignored) {}
        }
        return out;
    }

    // ---------- Data holder ----------
    static class SimulationResult {
        String tableText;
        int faults;
        int hits;
        SimulationResult(String t, int f, int h) { tableText = t; faults = f; hits = h; }
    }

    // ---------- Rendering helper ----------
    private String renderTable(List<Integer> refs, List<int[]> framesSnapshots, List<Boolean> hits, int frames) {
        // Build monospace table
        StringBuilder sb = new StringBuilder();
        // Header
        sb.append(fixed("Step", 6))
                .append(fixed("Ref", 6));
        for (int i = 0; i < frames; i++) sb.append(fixed("F"+(i+1), 6));
        sb.append(fixed("Hit/Fault", 10)).append("\n");

        sb.append(repeat('-', 6 + 6 + frames*6 + 10)).append("\n");

        for (int i = 0; i < refs.size(); i++) {
            sb.append(fixed(String.valueOf(i+1), 6))
                    .append(fixed(String.valueOf(refs.get(i)), 6));

            int[] snapshot = framesSnapshots.get(i);
            for (int f = 0; f < frames; f++) {
                String cell = (snapshot[f] == Integer.MIN_VALUE) ? "-" : String.valueOf(snapshot[f]);
                sb.append(fixed(cell, 6));
            }
            sb.append(fixed(hits.get(i) ? "HIT" : "FAULT", 10)).append("\n");
        }
        return sb.toString();
    }

    private String fixed(String s, int w) {
        if (s.length() >= w) return s.substring(0, w);
        StringBuilder b = new StringBuilder(s);
        while (b.length() < w) b.append(' ');
        return b.toString();
    }
    private String repeat(char c, int n) {
        char[] arr = new char[n];
        Arrays.fill(arr, c);
        return new String(arr);
    }

    // ---------- FIFO ----------
    private SimulationResult simulateFIFO(List<Integer> refs, int frames) {
        Queue<Integer> q = new LinkedList<>();
        Set<Integer> inFrames = new HashSet<>();
        int faults = 0, hits = 0;

        List<int[]> snapshots = new ArrayList<>();
        List<Boolean> hitList = new ArrayList<>();

        int[] frameArr = new int[frames];
        Arrays.fill(frameArr, Integer.MIN_VALUE);

        for (int r : refs) {
            boolean hit = inFrames.contains(r);
            if (hit) {
                hits++;
            } else {
                faults++;
                if (inFrames.size() < frames) {
                    // empty slot
                    for (int i = 0; i < frames; i++) {
                        if (frameArr[i] == Integer.MIN_VALUE) {
                            frameArr[i] = r;
                            inFrames.add(r);
                            q.offer(i); // track insertion order by slot index
                            break;
                        }
                    }
                } else {
                    // evict oldest
                    int idx = q.poll();
                    inFrames.remove(frameArr[idx]);
                    frameArr[idx] = r;
                    inFrames.add(r);
                    q.offer(idx);
                }
            }
            snapshots.add(Arrays.copyOf(frameArr, frames));
            hitList.add(hit);
        }

        String table = renderTable(refs, snapshots, hitList, frames);
        return new SimulationResult(table, faults, hits);
    }

    // ---------- LRU ----------
    // ---------- LRU ----------
    private SimulationResult simulateLRU(List<Integer> refs, int frames) {
        Map<Integer, Integer> lastUsed = new HashMap<>(); // page -> last index
        Set<Integer> inFrames = new HashSet<>();
        int faults = 0, hits = 0;

        List<int[]> snapshots = new ArrayList<>();
        List<Boolean> hitList = new ArrayList<>();
        int[] frameArr = new int[frames];
        Arrays.fill(frameArr, Integer.MIN_VALUE);

        for (int i = 0; i < refs.size(); i++) {
            int r = refs.get(i);
            boolean hit = inFrames.contains(r);
            if (hit) {
                hits++;
                lastUsed.put(r, i);
            } else {
                faults++;
                if (inFrames.size() < frames) {
                    // place in first empty slot
                    for (int s = 0; s < frames; s++) {
                        if (frameArr[s] == Integer.MIN_VALUE) {
                            frameArr[s] = r;
                            inFrames.add(r);
                            lastUsed.put(r, i);
                            break;
                        }
                    }
                } else {
                    // evict least recently used page
                    int victimPage = -1;
                    int victimLast = Integer.MAX_VALUE;
                    for (int p : inFrames) {
                        int lu = lastUsed.containsKey(p) ? lastUsed.get(p) : -1; // ✅ safe lookup
                        if (lu < victimLast) {
                            victimLast = lu;
                            victimPage = p;
                        }
                    }
                    // replace victim in frameArr
                    for (int s = 0; s < frames; s++) {
                        if (frameArr[s] == victimPage) {
                            frameArr[s] = r;
                            break;
                        }
                    }
                    inFrames.remove(victimPage);
                    inFrames.add(r);
                    lastUsed.put(r, i);
                }
            }
            snapshots.add(Arrays.copyOf(frameArr, frames));
            hitList.add(hit);
        }

        String table = renderTable(refs, snapshots, hitList, frames);
        return new SimulationResult(table, faults, hits);
    }


    // ---------- Optimal ----------
    private SimulationResult simulateOptimal(List<Integer> refs, int frames) {
        Set<Integer> inFrames = new HashSet<>();
        int faults = 0, hits = 0;

        List<int[]> snapshots = new ArrayList<>();
        List<Boolean> hitList = new ArrayList<>();
        int[] frameArr = new int[frames];
        Arrays.fill(frameArr, Integer.MIN_VALUE);

        for (int i = 0; i < refs.size(); i++) {
            int r = refs.get(i);
            boolean hit = inFrames.contains(r);
            if (hit) {
                hits++;
            } else {
                faults++;
                if (inFrames.size() < frames) {
                    // empty slot
                    for (int s = 0; s < frames; s++) {
                        if (frameArr[s] == Integer.MIN_VALUE) {
                            frameArr[s] = r;
                            inFrames.add(r);
                            break;
                        }
                    }
                } else {
                    // choose victim with farthest next use (or never used again)
                    int victimIdx = -1;
                    int farthest = -1; // distance to next use
                    for (int s = 0; s < frames; s++) {
                        int page = frameArr[s];
                        int nextUse = nextIndex(refs, i+1, page);
                        if (nextUse == -1) { // not used again -> perfect victim
                            victimIdx = s; break;
                        } else if (nextUse > farthest) {
                            farthest = nextUse;
                            victimIdx = s;
                        }
                    }
                    inFrames.remove(frameArr[victimIdx]);
                    frameArr[victimIdx] = r;
                    inFrames.add(r);
                }
            }
            snapshots.add(Arrays.copyOf(frameArr, frames));
            hitList.add(hit);
        }

        String table = renderTable(refs, snapshots, hitList, frames);
        return new SimulationResult(table, faults, hits);
    }

    private int nextIndex(List<Integer> refs, int start, int page) {
        for (int i = start; i < refs.size(); i++) {
            if (refs.get(i) == page) return i;
        }
        return -1;
    }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }
}
